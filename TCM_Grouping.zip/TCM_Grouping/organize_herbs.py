import os
import shutil
import re

# ==========================================
# 1. 配置区域
# ==========================================
source_dir_name = "总样本"        # 源文件夹 (336个文件)
target_base_dir_name = "中药数据集" # 目标父文件夹 (56个子文件夹)

# --- 中文名与简称映射 (用于将文件名翻译成中文进行比对) ---
# 注意：这里必须包含你所有可能的简称
herb_mapping = {
    "ch": "柴胡",
    "dg": "当归",
    "bz": "白术",
    "gc": "甘草",
    "sj": "生姜",
    "cx": "川芎",
    "rg": "肉桂",
    "sdh": "熟地黄"
}

# --- 允许的扩展名 ---
allowed_extensions = {'.txt', '.jpg', '.jpeg', '.png', '.bmp', '.gif', '.tiff'}

def extract_herbs_from_filename(filename):
    """从源文件名中提取两个药材的中文名称"""
    name_without_ext = os.path.splitext(filename)[0]
    # 匹配类似 bz+cx 或 ch_dg 的格式
    match = re.search(r'([a-z]+)[+\-_]([a-z]+)', name_without_ext.lower())
    if match:
        code1, code2 = match.group(1), match.group(2)
        # 将简称翻译成中文
        herb1 = herb_mapping.get(code1)
        herb2 = herb_mapping.get(code2)
        if herb1 and herb2:
            return {herb1, herb2} # 返回集合，方便后续判断
    return None

def extract_herbs_from_foldername(foldername):
    """从目标文件夹名中提取所有药材名称 (去除序号)"""
    # 去除开头的序号，如 "1." "12-" " 3 "
    clean_name = re.sub(r'^\d+\s*[.\-\)]*\s*', '', foldername)
    # 提取所有的中文药材名 (这里假设药材名是2-3个汉字)
    # 简单粗暴的方法：查找所有在 herb_mapping.values() 中的词
    found_herbs = set()
    for herb in herb_mapping.values():
        if herb in clean_name:
            found_herbs.add(herb)
    return found_herbs

def main():
    # 1. 获取脚本所在目录的绝对路径
    script_dir = os.path.dirname(os.path.abspath(__file__))
    source_path = os.path.join(script_dir, source_dir_name)
    target_base_path = os.path.join(script_dir, target_base_dir_name)

    # 2. 检查路径
    if not os.path.exists(source_path):
        print(f"❌ 错误: 找不到源文件夹 -> {source_path}")
        return
    if not os.path.exists(target_base_path):
        print(f"❌ 错误: 找不到目标文件夹 -> {target_base_path}")
        return

    print(f"✅ 路径检查通过！")
    print(f"🔍 扫描文件...")

    # 3. 获取所有源文件
    try:
        all_source_files = [
            f for f in os.listdir(source_path) 
            if os.path.isfile(os.path.join(source_path, f)) 
            and os.path.splitext(f)[1].lower() in allowed_extensions
        ]
    except Exception as e:
        print(f"❌ 读取源文件夹失败: {e}")
        return

    # 4. 遍历每一个目标子文件夹
    total_copied = 0
    for folder_name in os.listdir(target_base_path):
        folder_path = os.path.join(target_base_path, folder_name)
        
        if not os.path.isdir(folder_path):
            continue

        # --- 提取目标文件夹包含的药材 ---
        target_herbs_set = extract_herbs_from_foldername(folder_name)
        if len(target_herbs_set) < 2: # 安全检查，确保提取到了药材
            print(f"⚠️ 跳过文件夹 (未识别出药材): {folder_name}")
            continue

        print(f"\n📂 处理文件夹: [{folder_name}] (包含药材: {', '.join(target_herbs_set)})")
        folder_copy_count = 0

        # --- 遍历所有源文件，判断是否需要复制 ---
        for filename in all_source_files:
            # 提取源文件的药材组合
            file_herbs_set = extract_herbs_from_filename(filename)
            if not file_herbs_set:
                continue # 无法识别的文件名格式，跳过

            # --- 核心逻辑: 判断源文件的药材是否是目标文件夹药材的子集 ---
            # 例如：文件是 {柴胡, 当归}，文件夹是 {柴胡, 当归, 白术, 甘草, 生姜}
            # {柴胡, 当归} 是 大集合的子集 -> 符合条件
            if file_herbs_set.issubset(target_herbs_set):
                source_file = os.path.join(source_path, filename)
                dest_file = os.path.join(folder_path, filename)
                try:
                    shutil.copy2(source_file, dest_file) # 复制
                    folder_copy_count += 1
                    total_copied += 1
                except Exception as e:
                    print(f"   ❌ 复制失败 {filename}: {e}")

        print(f"✅ 该文件夹共复制入 {folder_copy_count} 个文件")

    # 5. 完成
    print("\n" + "="*50)
    print("🎉 任务完成!")
    print(f"📊 总共生成了 {total_copied} 个文件副本")
    print(f"💡 理论值: 56个文件夹 * 每个120个 = 6720个文件")
    print("="*50)

if __name__ == "__main__":
    main()