import os
import re
import sys

# ==========================================
# 1. 配置区域
# ==========================================
target_base_dir_name = "中药数据集"

# --- 中文名与简称映射 ---
herb_mapping = {
    "ch": "柴胡",
    "dg": "当归",
    "bz": "白术",
    "gc": "甘草",
    "sj": "生姜",
    "cx": "川芎",
    "rg": "肉桂",
    "sdh": "熟地黄"
}

def extract_herbs_from_filename(filename):
    """从文件名中提取两个药材的中文名称集合"""
    name_without_ext = os.path.splitext(filename)[0]
    # 匹配类似 bz+cx 或 ch_dg 的格式 (不区分大小写)
    match = re.search(r'([a-z]+)[+\-_]([a-z]+)', name_without_ext.lower())
    if match:
        code1, code2 = match.group(1), match.group(2)
        herb1 = herb_mapping.get(code1)
        herb2 = herb_mapping.get(code2)
        if herb1 and herb2:
            return {herb1, herb2}
    return None

def extract_herbs_from_foldername(foldername):
    """从文件夹名中提取所有药材的中文名称集合"""
    # 移除序号和点，例如 "5.柴胡+..."
    clean_name = re.sub(r'^\d+\.\s*', '', foldername)
    # 按 + 号分割
    parts = clean_name.split('+')
    herbs = set()
    for part in parts:
        part = part.strip()
        # 如果包含中文，直接加入
        if re.search(r'[\u4e00-\u9fff]', part):
            herbs.add(part)
        # 如果是简称 (如 ch)，通过映射转换
        else:
            full_name = herb_mapping.get(part.lower())
            if full_name:
                herbs.add(full_name)
    return herbs

def verify_folder_content(folder_path, folder_herbs, expected_count=120):
    """校验单个文件夹的内容"""
    errors = []
    file_count = 0

    try:
        # 遍历文件夹下的所有文件
        for entry in os.scandir(folder_path):
            if entry.is_file() and entry.name.lower().endswith('.txt'):
                file_count += 1
                # 检查内容逻辑
                file_herbs = extract_herbs_from_filename(entry.name)
                if file_herbs:
                    # 如果文件里的药材 不是 文件夹药材的子集 -> 错误
                    if not file_herbs.issubset(folder_herbs):
                        invalid_herbs = file_herbs - folder_herbs # 找出多出来的药材
                        errors.append((entry.name, invalid_herbs))
    except Exception as e:
        print(f"   ❌ 系统错误: 无法读取文件夹 - {e}", file=sys.stderr)
        return False

    # 结果汇总
    if file_count != expected_count:
        print(f"   ⚠️ 数量错误: 发现 {file_count} 个文件 (预期 {expected_count})")

    if errors:
        print(f"   🚫 逻辑错误 (发现 {len(errors)} 个非法文件):")
        # 逐行打印每一个错误，防止被省略号截断
        for filename, invalid_set in errors:
            print(f"      - [错] {filename:<30} (包含非法药材: {invalid_set})")
        return False

    return True

def main():
    # 获取脚本所在目录
    script_dir = os.path.dirname(os.path.abspath(__file__))
    base_path = os.path.join(script_dir, target_base_dir_name)

    if not os.path.exists(base_path):
        print(f"❌ 错误: 找不到目标文件夹 '{target_base_dir_name}'")
        return

    print(f"\n🚀 开始全量校验: {base_path}")
    print("="*50)

    total_folders = 0
    error_folders = 0

    # 主循环
    for folder_name in os.listdir(base_path):
        folder_path = os.path.join(base_path, folder_name)

        if os.path.isdir(folder_path):
            total_folders += 1
            print(f"\n[{total_folders:2d}] 处理中: {folder_name}")

            # 1. 提取文件夹应有的药材
            folder_herbs = extract_herbs_from_foldername(folder_name)
            if not folder_herbs:
                print(f"   ⚠️ 跳过: 无法识别文件夹药材 -> {folder_name}")
                continue

            # 2. 执行校验
            if not verify_folder_content(folder_path, folder_herbs):
                error_folders += 1

    print("\n" + "="*50)
    print(f"📊 校验报告完成!")
    print(f"   总文件夹数: {total_folders}")
    if error_folders == 0:
        print(f"   结果: 🎉 所有文件夹均正确 (120/120)!")
    else:
        print(f"   结果: ❌ 发现 {error_folders} 个异常文件夹，请检查上述日志。")

if __name__ == "__main__":
    main()